import React from 'react'

const Hero = () => {
  return (
    <>
        <div>
            <div></div>
            <div>
                <div>
                    <h1></h1>
                    <h1></h1>
                    <button></button>
                    <div></div>
                    <div></div>
                </div>
                <div>
                    <img 
                        src="" 
                        alt="hero-img/img"
                         />
                </div>
            </div>
        </div>
    </>
  )
}

export default Hero