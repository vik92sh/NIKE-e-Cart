import React from 'react'
import { Hero } from './components'

const App = () => {
  return (
   <>
    {/* <div className='bg-slate-900 h-screen grid place-content-center'>
      <h1 className='text-yellow-500 font-bold text-4xl'>NIKE</h1>
    </div> */}
    <main>
      <Hero/>
    </main>
   </>
  )
}

export default App